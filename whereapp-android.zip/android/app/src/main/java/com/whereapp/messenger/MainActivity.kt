package com.whereapp.messenger

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Оболочка вокруг сайта WhereApp.
 *
 * Сам интерфейс — это тот же сайт в WebView, поэтому всё, что работает
 * в браузере (чаты, звонки, шифрование), работает и здесь без изменений.
 * Разница в другом: рядом крутится служба переднего плана, которая
 * следит за новыми сообщениями и показывает уведомления даже когда
 * приложение закрыто. Именно её Android не имеет права выгружать.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        // Адрес сайта. Если сменишь домен — правь только эту строку.
        const val SITE = "https://corip2000.github.io/"
        const val PREFS = "whereapp"
    }

    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val cb = filePathCallback ?: return@registerForActivityResult
        filePathCallback = null
        cb.onReceiveValue(
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        )
    }

    private val permissionAsker = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        askPermissions()

        web = WebView(this)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        // Мост: сайт передаёт сюда свой идентификатор и ключи чатов,
        // чтобы служба могла расшифровать текст для уведомления.
        web.addJavascriptInterface(Bridge(this), "WhereAppNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, req: WebResourceRequest?): Boolean {
                val url = req?.url?.toString() ?: return false
                // Внутренние ссылки открываем здесь, внешние — в браузере
                if (url.startsWith(SITE)) return false
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                // Подсказываем сайту, что он внутри приложения
                view?.evaluateJavascript("window.__WHEREAPP_NATIVE__ = true;", null)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // Разрешения на камеру и микрофон для звонков
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    filePicker.launch(params?.createIntent())
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        if (savedInstanceState == null) web.loadUrl(SITE)

        WatchService.start(this)
    }

    private fun askPermissions() {
        val need = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionAsker.launch(missing.toTypedArray())
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        web.restoreState(savedInstanceState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Мост между сайтом и приложением. */
    class Bridge(private val ctx: Context) {

        @JavascriptInterface
        fun setUid(uid: String) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("uid", uid).apply()
            WatchService.start(ctx)
        }

        /** Ключ чата в base64 — нужен, чтобы показать текст сообщения в уведомлении. */
        @JavascriptInterface
        fun saveKey(chatId: String, keyB64: String) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("key_$chatId", keyB64).apply()
        }

        @JavascriptInterface
        fun saveName(uid: String, name: String) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("name_$uid", name).apply()
        }

        /** Сайт сообщает, какой чат сейчас открыт — по нему уведомления не шлём. */
        @JavascriptInterface
        fun setActiveChat(chatId: String) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("active", chatId).apply()
        }

        @JavascriptInterface
        fun toast(text: String) {
            Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
        }
    }
}
