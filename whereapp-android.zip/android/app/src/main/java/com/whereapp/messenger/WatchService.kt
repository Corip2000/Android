package com.whereapp.messenger

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import android.util.Base64
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Служба переднего плана.
 *
 * Держит постоянное уведомление в шторке — благодаря ему Android не имеет
 * права выгрузить процесс, и опрос сервера продолжается даже когда
 * приложение закрыто. Это и есть главное отличие от сайта в браузере:
 * веб-странице такую службу завести нельзя.
 *
 * Текст сообщений расшифровывается прямо здесь, ключами, которые сайт
 * передал через мост. На сервер расшифрованный текст не уходит никогда.
 */
class WatchService : Service() {

    companion object {
        const val SUPA_URL = "https://zvdwimgmbxhvvdnmjuag.supabase.co"
        const val SUPA_KEY = "sb_publishable_0FbeQ-Y9mtRqlKHmKRXrHw_RjI-EHa1"

        private const val CH_SILENT = "whereapp_service"
        private const val CH_ALERT = "whereapp_messages"
        private const val ONGOING_ID = 1
        private const val POLL_MS = 8_000L

        fun start(ctx: Context) {
            val i = Intent(ctx, WatchService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(ONGOING_ID, ongoingNotification())
        startLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (job?.isActive != true) startLoop()
        return START_STICKY   // система перезапустит службу, если всё же убьёт
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Приложение смахнули из списка — служба должна продолжать работать
        start(this)
        super.onTaskRemoved(rootIntent)
    }

    private fun prefs() = getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(CH_SILENT, "Работа в фоне", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Постоянное уведомление, без него Android выгружает приложение"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Сообщения", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Новые сообщения и звонки"
                enableVibration(true)
                enableLights(true)
            }
        )
    }

    private fun ongoingNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_SILENT)
            .setContentTitle("WhereApp на связи")
            .setContentText("Следит за новыми сообщениями")
            .setSmallIcon(R.mipmap.ic_stat)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .build()
    }

    private fun startLoop() {
        job = scope.launch {
            while (isActive) {
                try { poll() } catch (_: Exception) { }
                delay(POLL_MS)
            }
        }
    }

    private fun get(path: String): String? {
        val req = Request.Builder()
            .url("$SUPA_URL/rest/v1/$path")
            .header("apikey", SUPA_KEY)
            .header("Authorization", "Bearer $SUPA_KEY")
            .build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            return r.body?.string()
        }
    }

    private suspend fun poll() {
        val p = prefs()
        val uid = p.getString("uid", null) ?: return
        var since = p.getLong("since", 0L)
        if (since == 0L) {
            // Первый запуск: считаем прочитанным всё, что было раньше
            since = System.currentTimeMillis()
            p.edit().putLong("since", since).apply()
            return
        }

        // Чаты, где я состою
        val chatsJson = get("chats?select=id,type,name,members&members=cs." +
                URLEncoder.encode("{$uid}", "UTF-8")) ?: return
        val chats = JSONArray(chatsJson)
        if (chats.length() == 0) return

        val ids = ArrayList<String>()
        val titles = HashMap<String, String>()
        val isGroup = HashMap<String, Boolean>()
        for (i in 0 until chats.length()) {
            val c = chats.getJSONObject(i)
            val id = c.getString("id")
            ids.add(id)
            val type = c.optString("type", "direct")
            isGroup[id] = (type == "group")
            titles[id] = if (type == "group") c.optString("name", "Группа") else ""
        }

        val inList = ids.joinToString(",") { "\"$it\"" }
        val msgsJson = get(
            "messages?select=id,chat_id,from_uid,ts,kind,ct,iv" +
                    "&chat_id=in.(" + URLEncoder.encode(inList, "UTF-8") + ")" +
                    "&ts=gt.$since&order=ts.asc&limit=25"
        ) ?: return

        val msgs = JSONArray(msgsJson)
        if (msgs.length() == 0) return

        var maxTs = since
        val active = p.getString("active", "") ?: ""

        for (i in 0 until msgs.length()) {
            val m = msgs.getJSONObject(i)
            val ts = m.optLong("ts", 0L)
            if (ts > maxTs) maxTs = ts

            val from = m.optString("from_uid", "")
            if (from == uid) continue
            if (m.optString("kind", "") == "sys") continue

            val chatId = m.optString("chat_id", "")
            if (chatId == active && isAppForeground()) continue

            val sender = senderName(from)
            val group = isGroup[chatId] == true
            val title = if (group) (titles[chatId] ?: "Группа") else sender

            var body = when (m.optString("kind", "text")) {
                "image" -> "\uD83D\uDCF7 Фото"
                "audio" -> "\uD83C\uDFA4 Голосовое"
                "video" -> "\uD83C\uDFAC Видео"
                "file" -> "\uD83D\uDCCE Файл"
                else -> "Новое сообщение"
            }

            if (m.optString("kind", "") == "text" && !m.isNull("ct")) {
                val text = decrypt(chatId, m.optString("ct"), m.optString("iv"))
                if (text != null) body = text
            }
            if (group) body = "$sender: $body"

            showMessage(m.optString("id", ts.toString()), title, body)
        }

        p.edit().putLong("since", maxTs).apply()
    }

    private fun senderName(uid: String): String {
        val cached = prefs().getString("name_$uid", null)
        if (cached != null) return cached
        return try {
            val js = get("profiles?select=name&id=eq." + URLEncoder.encode(uid, "UTF-8"))
            val arr = JSONArray(js ?: "[]")
            val name = if (arr.length() > 0) arr.getJSONObject(0).optString("name", "Сообщение") else "Сообщение"
            prefs().edit().putString("name_$uid", name).apply()
            name
        } catch (e: Exception) { "Сообщение" }
    }

    /** Расшифровка тем же алгоритмом, что и в браузере: AES-GCM, метка 128 бит. */
    private fun decrypt(chatId: String, ctB64: String, ivB64: String): String? {
        return try {
            val keyB64 = prefs().getString("key_$chatId", null) ?: return null
            val key = SecretKeySpec(Base64.decode(keyB64, Base64.NO_WRAP), "AES")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, Base64.decode(ivB64, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(ctB64, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) { null }
    }

    private fun isAppForeground(): Boolean {
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.runningAppProcesses?.any {
                it.processName == packageName &&
                        it.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
            } ?: false
        } catch (e: Exception) { false }
    }

    private fun showMessage(id: String, title: String, body: String) {
        val open = PendingIntent.getActivity(
            this, id.hashCode(), Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.mipmap.ic_stat)
            .setLargeIcon(BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        // Своя метка у каждого сообщения, иначе система молча подменяет предыдущее
        nm.notify(id.hashCode(), n)
    }
}
