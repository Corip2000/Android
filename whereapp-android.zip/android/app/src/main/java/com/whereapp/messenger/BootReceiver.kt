package com.whereapp.messenger

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Поднимает службу после перезагрузки телефона. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            WatchService.start(context)
        }
    }
}
